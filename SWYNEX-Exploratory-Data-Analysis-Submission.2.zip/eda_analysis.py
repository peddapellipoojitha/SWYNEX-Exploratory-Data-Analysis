import os
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('Cleaned_Supermarket_Sales.csv')
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
for c in ['Quantity','Unit_Price_INR','Total_Amount_INR']:
    df[c] = pd.to_numeric(df[c], errors='coerce')
for c in ['City','Category','Payment_Method','Product']:
    df[c] = df[c].astype('string').str.strip().str.title()
sales = df.dropna(subset=['Total_Amount_INR'])
print(df[['Quantity','Unit_Price_INR','Total_Amount_INR']].describe())
for field in ['Category','City','Payment_Method']:
    print('\\nSales by', field)
    print(sales.groupby(field)['Total_Amount_INR'].agg(['sum','count','mean']).sort_values('sum', ascending=False))
print('Missing dates:', df['Date'].isna().sum())
print('Missing sales amounts:', df['Total_Amount_INR'].isna().sum())
print('Negative amount rows:', (df['Total_Amount_INR'] < 0).sum())
os.makedirs('charts', exist_ok=True)
for field, fname in [('Category','sales_by_category.png'),('City','sales_by_city.png'),('Payment_Method','sales_by_payment.png')]:
    sales.groupby(field)['Total_Amount_INR'].sum().sort_values().plot(kind='barh', figsize=(9,5), title='Sales by '+field)
    plt.xlabel('Sales (INR)'); plt.tight_layout(); plt.savefig('charts/'+fname, dpi=160); plt.close()
sales.groupby('Product')['Total_Amount_INR'].sum().nlargest(10).sort_values().plot(kind='barh', figsize=(9,5), title='Top 10 Products by Sales')
plt.xlabel('Sales (INR)'); plt.tight_layout(); plt.savefig('charts/top_products.png', dpi=160); plt.close()
sales.dropna(subset=['Date']).groupby('Date')['Total_Amount_INR'].sum().plot(marker='o', figsize=(10,5), title='Daily Sales Trend')
plt.ylabel('Sales (INR)'); plt.tight_layout(); plt.savefig('charts/daily_sales_trend.png', dpi=160); plt.close()
